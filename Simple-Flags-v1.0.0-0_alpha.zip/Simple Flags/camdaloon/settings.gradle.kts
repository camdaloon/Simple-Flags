rootProject.name = "SimpleFlags"
